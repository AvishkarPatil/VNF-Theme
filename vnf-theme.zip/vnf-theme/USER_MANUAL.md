<h1 align="center">Voice of Needy Foundation (VNF)</h1>
<p align="center"><strong>Website Administration & CMS User Manual</strong></p>

---

Welcome to the **VNF Website User Manual**. Unlike a generic Ghost CMS tutorial, this manual is written specifically for the **Custom VNF Theme** you are running. We built this website to be highly dynamic, meaning almost the entire homepage and complex layouts are automatically generated based on how you tag your articles!

## Table of Contents
1. [Logging In & Basics](#1-logging-in--basics)
2. [How to Edit the Homepage (Section by Section)](#2-how-to-edit-the-homepage-section-by-section)
3. [Publishing General News & Updates](#3-publishing-general-news--updates)
4. [Editing Custom Pages (Donate, Team, Partner, Contact)](#4-editing-custom-pages-donate-team-partner-contact)
5. [Updating Navigation Menus (Navbar)](#5-updating-navigation-menus-navbar)
6. [Updating Logos & Branding](#6-updating-logos--branding)

---

## 1. Logging In & Basics
1. Go to your Admin URL: **`yourwebsite.com/ghost`** 
2. Enter your Email and Password.
3. **The Golden Rule of Ghost:** 
   - **Posts** are for dynamic content (News, Programs, Beneficiary Stories).
   - **Pages** are for permanent layouts (About Us, Donate, Team).

---

## 2. How to Edit the Homepage (Section by Section)
The VNF homepage is deeply integrated into your Ghost Database. You do not need to code to change the homepage; you just need to update posts with specific **Tags** or use the **Design Settings**.

### 🔹 The Hero Slider (Top Animation)
To add a new slide to the massive animated banner at the very top of the site:
1. Create a **New Post**.
2. **Title:** This will be the main big text on the slide.
3. **Excerpt:** This will be the small subtitle paragraph below the main text.
4. **Feature Image:** This will become the full-screen background photo!
5. **The Secret:** Open the Post Settings (⚙️) and add the tag `hero-slides`.
6. Publish it! The website will automatically grab up to 5 posts with this tag and build the slider.

### 🔹 The "About" Section (Typography & Images)
- **To change the Text:** Go to **Pages**, and edit the page that has the exact URL/Slug `home-about`. Whatever you type in that page will automatically appear on the homepage.
- **To change the 3 Masonry Photos:** Go to the bottom left **Settings Gear (⚙️)** > **Design & Branding** > Click **Customize** > open **Sitewide**. You will see custom image upload buttons specifically for `About Image 1`, `About Image 2`, and `About Image 3`.

### 🔹 Mission & Vision Images
- To swap the video thumbnails for the Mission and Vision boxes, go to **Settings (⚙️)** > **Design & Branding** > **Customize** > **Sitewide**. Upload your new photos to the `Mission Image` and `Vision Image` fields.

### 🔹 Impact Stats (The Number Counters) & "Our Approach"
- Because of the complex math and exact layout constraints, the large counting numbers (like 3000+, 2300+) and the "Our Approach" text are permanently hardcoded directly into the theme files. If your organizational numbers grow and need updating, notify your developer to tweak the HTML numbers quickly.

### 🔹 Our Programs Grid
- The grid of custom colored cards automatically pulls your top 6 initiatives.
- **To add a Program:** Create a **New Post** with a Feature Image and a Title. In the Settings, give it the exact tag `programs`. It will automatically generate a new card on the homepage!

### 🔹 Stories of Change (The Horizontal Slider)
- **To add a Success Story:** Create a **New Post** highlighting the beneficiary. Give it a Feature Image.
- In the Settings, add the exact tag `success-stories`. 
- The homepage will grab the newest 6 stories and create the swiping carousel automatically.

### 🔹 Voices of Change (The Yellow Quote Testimonials)
- **To change the highlighted quote:** Create a **New Post**.
- In the Settings, add the tag `testimonials`.
- **Title:** The person's name (e.g., "Arun Kumar S.").
- **Excerpt:** The actual quote (e.g., "Out of compassion towards...").
- **Custom Excerpt:** The person's role (e.g., "Founder").
- Publish it! The homepage will grab the newest post with this tag and build the beautiful yellow quote box.

---

## 3. Publishing General News & Updates
If you just want to publish standard charity updates or news:
1. Go to **Posts** -> **New Post**.
2. Write your content, add a great Feature Image, and hit Publish. 
3. *Note:* As long as you DO NOT tag them with `hero-slides`, `programs`, or `success-stories`, they will simply route to your standard News/Blog feed, keeping your homepage perfectly clean.

---

## 4. Editing Custom Pages (Donate, Team, Partner, Contact)
We built specialized visual templates for your most important pages.
1. Go to **Pages**.
2. Open the page you want to edit (e.g., "Team").
3. You can edit the text natively. 
4. **CRITICAL:** Ensure the page is using its custom theme layout! Open the **Settings (⚙️)**, scroll down to the **Template** dropdown, and make sure `Custom Team` is selected instead of "Default". 
   *(Available templates: Custom About, Custom Contact, Custom Donate, Custom Partner, Custom Team).*

---

## 5. Updating Navigation Menus (Navbar)
To change the links at the very top of the website or in the footer:
1. Click the **Settings Gear (⚙️)** in the bottom left corner.
2. Click on **Navigation**.
3. Under **Primary Navigation**, add the Name of the link you want (e.g., "Our Story") and paste the URL next to it.
4. Drag and drop them to reorder. Click **Save**.

---

## 6. Updating Logos & Branding
1. Click the **Settings Gear (⚙️)** in the bottom left.
2. Go to **Design & Branding** -> **Brand**.
3. From here, you can upload the main **Publication Logo** (appears in the navbar), the **Icon** (appears on browser tabs), and the default **Cover Image**.


<br>
<hr>
<p align="center"><i>End of manual. Exclusively built and documented for the Voice of Needy Foundation (VNF).</i></p>
